//��������keyboard_s����������ID
#define  _SCREEN_KEYBOARD_S                                                    0

//��������S_1����������ID
#define  _SCREEN_S_1                                                           1

//��������S_password1����������ID
#define  _SCREEN_S_PASSWORD1                                                   2

//��������S_password2����������ID
#define  _SCREEN_S_PASSWORD2                                                   3

//��������S_PID����������ID
#define  _SCREEN_S_PID                                                         4

//��������S_menu����������ID
#define  _SCREEN_S_MENU                                                        5

//��������S_Shutoff_recovery����������ID
#define  _SCREEN_S_SHUTOFF_RECOVERY                                            6

//��������Screen3����������ID
#define  _SCREEN_SCREEN3                                                       7

//��������S_time����������ID
#define  _SCREEN_S_TIME                                                        8

//��������S_wrong_password����������ID
#define  _SCREEN_S_WRONG_PASSWORD                                              9

//��������S_wrong_setting����������ID
#define  _SCREEN_S_WRONG_SETTING                                              10

//��������S_wrong_setting2����������ID
#define  _SCREEN_S_WRONG_SETTING2                                             11

//��������S_main����������ID
#define  _SCREEN_S_MAIN                                                       12

//��������S_adjustmenu����������ID
#define  _SCREEN_S_ADJUSTMENU                                                 13

//��������S_ErrorTime����������ID
#define  _SCREEN_S_ERRORTIME                                                  14

//��������E_14����������ID
#define  _SCREEN_E_14                                                         15

//��������E_password1����������ID
#define  _SCREEN_E_PASSWORD1                                                  16

//��������E_password2����������ID
#define  _SCREEN_E_PASSWORD2                                                  17

//��������E_PID����������ID
#define  _SCREEN_E_PID                                                        18

//��������E_menu����������ID
#define  _SCREEN_E_MENU                                                       19

//��������E_shutoff_recovery����������ID
#define  _SCREEN_E_SHUTOFF_RECOVERY                                           20

//��������E_15����������ID
#define  _SCREEN_E_15                                                         21

//��������E_time����������ID
#define  _SCREEN_E_TIME                                                       22

//��������E_wrong_password����������ID
#define  _SCREEN_E_WRONG_PASSWORD                                             23

//��������E_wrong_setting����������ID
#define  _SCREEN_E_WRONG_SETTING                                              24

//��������E_wrong_setting2����������ID
#define  _SCREEN_E_WRONG_SETTING2                                             25

//��������E_main����������ID
#define  _SCREEN_E_MAIN                                                       26

//��������E_adjustmenu����������ID
#define  _SCREEN_E_ADJUSTMENU                                                 27

//��������E_ErrorTime����������ID
#define  _SCREEN_E_ERRORTIME                                                  28

//����keyboard_s��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_KEYBOARD_S_IMAGE1                                                0

#define  _TXT_DIS__KEYBOARD_S_TEXT_DISPLAY1                                    2

#define  _BTN_KEYBOARD_S_BUTTON1                                               3

#define  _BTN_KEYBOARD_S_BUTTON2                                               4

#define  _BTN_KEYBOARD_S_BUTTON3                                               5

#define  _BTN_KEYBOARD_S_BUTTON4                                               6

#define  _BTN_KEYBOARD_S_BUTTON5                                               7

#define  _BTN_KEYBOARD_S_BUTTON6                                               8

#define  _BTN_KEYBOARD_S_BUTTON7                                               9

#define  _BTN_KEYBOARD_S_BUTTON8                                              10

#define  _BTN_KEYBOARD_S_BUTTON9                                              11

#define  _BTN_KEYBOARD_S_BUTTON10                                             12

#define  _BTN_KEYBOARD_S_BUTTON11                                             13

#define  _BTN_KEYBOARD_S_BUTTON12                                             14

#define  _BTN_KEYBOARD_S_BUTTON13                                             15

#define  _BTN_KEYBOARD_S_BUTTON14                                             16

#define  _BTN_KEYBOARD_S_BUTTON15                                             17

//����S_password1�ı���ͼƬ
#define  _IMG_S_PASSWORD1                                                      1

#define  _TXT_DIS__S_PASSWORD1_TEXT_DISPLAY1                                   2

//����S_password2��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_S_PASSWORD2_IMAGE1                                               1

#define  _TXT_DIS__S_PASSWORD2_TEXT_DISPLAY1                                   2

//����S_PID��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_S_PID_IMAGE1                                                     2

#define  _TXT_DIS__S_PID_TEXT_DISPLAY6                                         4

#define  _TXT_DIS__S_PID_TEXT_DISPLAY1                                         5

#define  _TXT_DIS__S_PID_TEXT_DISPLAY2                                         6

#define  _BTN_S_PID_BUTTON1                                                    2

#define  _BTN_S_PID_BUTTON2                                                    3

//����S_menu��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_S_MENU_IMAGE1                                                    3

#define  _BTN_S_MENU_BUTTON1                                                  21

//����S_menu�ж����ؼ�Icon1ʹ�õ�ͼƬ
#define  _IMG_S_MENU_ICON1                                                     4

#define  _ANIMATION_S_MENU_ICON1                                              19

//����S_menu�ж����ؼ�Icon7ʹ�õ�ͼƬ
#define  _IMG_S_MENU_ICON7                                                     4

#define  _ANIMATION_S_MENU_ICON7                                              20

#define  _BTN_S_MENU_BUTTON2                                                   2

//����S_menu�ж����ؼ�Icon8ʹ�õ�ͼƬ
#define  _IMG_S_MENU_ICON8                                                     4

#define  _ANIMATION_S_MENU_ICON8                                              14

//����S_menu�ж����ؼ�Icon9ʹ�õ�ͼƬ
#define  _IMG_S_MENU_ICON9                                                     4

#define  _ANIMATION_S_MENU_ICON9                                              15

//����S_menu�ж����ؼ�Icon10ʹ�õ�ͼƬ
#define  _IMG_S_MENU_ICON10                                                    4

#define  _ANIMATION_S_MENU_ICON10                                             16

//����S_menu�ж����ؼ�Icon11ʹ�õ�ͼƬ
#define  _IMG_S_MENU_ICON11                                                    4

#define  _ANIMATION_S_MENU_ICON11                                             17

#define  _TXT_DIS__S_MENU_TEXT_DISPLAY1                                        3

#define  _TXT_DIS__S_MENU_TEXT_DISPLAY2                                        4

#define  _TXT_DIS__S_MENU_TEXT_DISPLAY3                                        5

#define  _TXT_DIS__S_MENU_TEXT_DISPLAY4                                        9

#define  _TXT_DIS__S_MENU_TEXT_DISPLAY5                                       10

#define  _TXT_DIS__S_MENU_TEXT_DISPLAY6                                        7

#define  _TXT_DIS__S_MENU_TEXT_DISPLAY7                                       18

#define  _TXT_DIS__S_MENU_TEXT_DISPLAY8                                       13

#define  _BTN_S_MENU_BUTTON3                                                  22

#define  _BTN_S_MENU_BUTTON4                                                  23

#define  _BTN_S_MENU_BUTTON5                                                  24

#define  _BTN_S_MENU_BUTTON6                                                  25

#define  _BTN_S_MENU_BUTTON7                                                  26

#define  _BTN_S_MENU_BUTTON8                                                  27

//����S_Shutoff_recovery��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_S_SHUTOFF_RECOVERY_IMAGE1                                        5

#define  _TXT_DIS__S_SHUTOFF_RECOVERY_TEXT_DISPLAY1                            2

//����S_time��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_S_TIME_IMAGE1                                                    6

#define  _TXT_DIS__S_TIME_TEXT_DISPLAY1                                        2

#define  _TXT_DIS__S_TIME_TEXT_DISPLAY2                                        3

#define  _TXT_DIS__S_TIME_TEXT_DISPLAY3                                        4

#define  _TXT_DIS__S_TIME_TEXT_DISPLAY4                                        5

#define  _TXT_DIS__S_TIME_TEXT_DISPLAY5                                        6

#define  _TXT_DIS__S_TIME_TEXT_DISPLAY6                                        7

#define  _BTN_S_TIME_BUTTON2                                                   8

//����S_wrong_password��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_S_WRONG_PASSWORD_IMAGE1                                          7

#define  _BTN_S_WRONG_PASSWORD_BUTTON2                                         2

//����S_wrong_setting��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_S_WRONG_SETTING_IMAGE1                                           8

#define  _BTN_S_WRONG_SETTING_BUTTON2                                         10

//����S_wrong_setting�ж����ؼ�Icon1ʹ�õ�ͼƬ
#define  _IMG_S_WRONG_SETTING_ICON1                                            9

#define  _ANIMATION_S_WRONG_SETTING_ICON1                                      2

//����S_wrong_setting�ж����ؼ�Icon3ʹ�õ�ͼƬ
#define  _IMG_S_WRONG_SETTING_ICON3                                            9

#define  _ANIMATION_S_WRONG_SETTING_ICON3                                      3

//����S_wrong_setting�ж����ؼ�Icon4ʹ�õ�ͼƬ
#define  _IMG_S_WRONG_SETTING_ICON4                                            9

#define  _ANIMATION_S_WRONG_SETTING_ICON4                                      4

//����S_wrong_setting�ж����ؼ�Icon5ʹ�õ�ͼƬ
#define  _IMG_S_WRONG_SETTING_ICON5                                            9

#define  _ANIMATION_S_WRONG_SETTING_ICON5                                      5

//����S_wrong_setting�ж����ؼ�Icon6ʹ�õ�ͼƬ
#define  _IMG_S_WRONG_SETTING_ICON6                                            9

#define  _ANIMATION_S_WRONG_SETTING_ICON6                                      6

//����S_wrong_setting�ж����ؼ�Icon7ʹ�õ�ͼƬ
#define  _IMG_S_WRONG_SETTING_ICON7                                            9

#define  _ANIMATION_S_WRONG_SETTING_ICON7                                      8

//����S_wrong_setting�ж����ؼ�Icon2ʹ�õ�ͼƬ
#define  _IMG_S_WRONG_SETTING_ICON2                                            9

#define  _ANIMATION_S_WRONG_SETTING_ICON2                                      9

//����S_wrong_setting2��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_S_WRONG_SETTING2_IMAGE1                                         10

#define  _BTN_S_WRONG_SETTING2_BUTTON1                                         6

//����S_wrong_setting2�ж����ؼ�Icon2ʹ�õ�ͼƬ
#define  _IMG_S_WRONG_SETTING2_ICON2                                           9

#define  _ANIMATION_S_WRONG_SETTING2_ICON2                                     4

//����S_wrong_setting2�ж����ؼ�Icon3ʹ�õ�ͼƬ
#define  _IMG_S_WRONG_SETTING2_ICON3                                           9

#define  _ANIMATION_S_WRONG_SETTING2_ICON3                                     2

//����S_wrong_setting2�ж����ؼ�Icon4ʹ�õ�ͼƬ
#define  _IMG_S_WRONG_SETTING2_ICON4                                           9

#define  _ANIMATION_S_WRONG_SETTING2_ICON4                                     5

//����S_main��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_S_MAIN_IMAGE1                                                   11

//����S_main�ж����ؼ�Icon1ʹ�õ�ͼƬ
#define  _IMG_S_MAIN_ICON1                                                    12

#define  _ANIMATION_S_MAIN_ICON1                                               2

//����S_main�ж����ؼ�Icon3ʹ�õ�ͼƬ
#define  _IMG_S_MAIN_ICON3                                                    13

#define  _ANIMATION_S_MAIN_ICON3                                               4

//����S_main�ж����ؼ�Icon5ʹ�õ�ͼƬ
#define  _IMG_S_MAIN_ICON5                                                    14

#define  _ANIMATION_S_MAIN_ICON5                                               6

//����S_main�ж����ؼ�Icon6ʹ�õ�ͼƬ
#define  _IMG_S_MAIN_ICON6                                                    15

#define  _ANIMATION_S_MAIN_ICON6                                               5

//����S_main�ж����ؼ�Icon8ʹ�õ�ͼƬ
#define  _IMG_S_MAIN_ICON8                                                    16

#define  _ANIMATION_S_MAIN_ICON8                                              12

//����S_main�ж����ؼ�Icon9ʹ�õ�ͼƬ
#define  _IMG_S_MAIN_ICON9                                                    17

#define  _ANIMATION_S_MAIN_ICON9                                              14

#define  _TXT_DIS__S_MAIN_TEXT_DISPLAY1                                       21

#define  _TXT_DIS__S_MAIN_TEXT_DISPLAY2                                       23

#define  _TXT_DIS__S_MAIN_TEXT_DISPLAY3                                       25

#define  _TXT_DIS__S_MAIN_TEXT_DISPLAY4                                       26

#define  _TXT_DIS__S_MAIN_TEXT_DISPLAY5                                       29

#define  _TXT_DIS__S_MAIN_TEXT_DISPLAY6                                       28

#define  _TXT_DIS__S_MAIN_TEXT_DISPLAY7                                       27

//����S_main�ж����ؼ�Icon4ʹ�õ�ͼƬ
#define  _IMG_S_MAIN_ICON4                                                    18

#define  _ANIMATION_S_MAIN_ICON4                                              33

#define  _TXT_DIS__S_MAIN_TEXT_DISPLAY8                                       34

#define  _BTN_S_MAIN_BUTTON1                                                  16

#define  _BTN_S_MAIN_BUTTON4                                                  20

#define  _TXT_DIS__S_MAIN_TEXT_DISPLAY9                                       22

#define  _TXT_DIS__S_MAIN_TEXT_DISPLAY10                                      24

#define  _TXT_DIS__S_MAIN_TEXT_DISPLAY11                                      30

//����S_main�ж����ؼ�Icon2ʹ�õ�ͼƬ
#define  _IMG_S_MAIN_ICON2                                                    19

#define  _ANIMATION_S_MAIN_ICON2                                               3

#define  _BTN_S_MAIN_BUTTON2                                                  19

//����S_main�ж����ؼ�Icon7ʹ�õ�ͼƬ
#define  _IMG_S_MAIN_ICON7                                                    20

#define  _ANIMATION_S_MAIN_ICON7                                             340

//����S_main�ж����ؼ�Icon10ʹ�õ�ͼƬ
#define  _IMG_S_MAIN_ICON10                                                   20

#define  _ANIMATION_S_MAIN_ICON10                                            330

#define  _RTC_S_MAIN_RTC1                                                      7

//����S_adjustmenu��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_S_ADJUSTMENU_IMAGE1                                             21

#define  _TXT_DIS__S_ADJUSTMENU_TEXT_DISPLAY1                                  6

#define  _TXT_DIS__S_ADJUSTMENU_TEXT_DISPLAY2                                  7

#define  _TXT_DIS__S_ADJUSTMENU_TEXT_DISPLAY3                                  8

#define  _BTN_S_ADJUSTMENU_BUTTON2                                             9

#define  _TXT_DIS__S_ADJUSTMENU_TEXT_DISPLAY4                                  2

#define  _TXT_DIS__S_ADJUSTMENU_TEXT_DISPLAY5                                  3

#define  _TXT_DIS__S_ADJUSTMENU_TEXT_DISPLAY6                                  5

#define  _BTN_S_ADJUSTMENU_BUTTON1                                            11

//����S_ErrorTime��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_S_ERRORTIME_IMAGE1                                              22

#define  _BTN_S_ERRORTIME_BUTTON1                                              2

#define  _TXT_DIS__S_ERRORTIME_TEXT_DISPLAY1                                   3

//����E_password1��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_E_PASSWORD1_IMAGE1                                              23

#define  _TXT_DIS__E_PASSWORD1_TEXT_DISPLAY1                                   2

//����E_password2��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_E_PASSWORD2_IMAGE1                                              23

#define  _TXT_DIS__E_PASSWORD2_TEXT_DISPLAY1                                   2

//����E_PID��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_E_PID_IMAGE1                                                    24

#define  _TXT_DIS__E_PID_TEXT_DISPLAY1                                         4

#define  _TXT_DIS__E_PID_TEXT_DISPLAY2                                         5

#define  _TXT_DIS__E_PID_TEXT_DISPLAY3                                         6

#define  _BTN_E_PID_BUTTON1                                                    2

#define  _BTN_E_PID_BUTTON2                                                    3

//����E_menu��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_E_MENU_IMAGE1                                                   25

#define  _BTN_E_MENU_BUTTON1                                                   2

#define  _BTN_E_MENU_BUTTON2                                                  21

#define  _TXT_DIS__E_MENU_TEXT_DISPLAY1                                        3

#define  _TXT_DIS__E_MENU_TEXT_DISPLAY2                                        4

#define  _TXT_DIS__E_MENU_TEXT_DISPLAY3                                        5

#define  _TXT_DIS__E_MENU_TEXT_DISPLAY4                                        7

#define  _TXT_DIS__E_MENU_TEXT_DISPLAY5                                       18

#define  _TXT_DIS__E_MENU_TEXT_DISPLAY6                                       13

#define  _TXT_DIS__E_MENU_TEXT_DISPLAY7                                        9

#define  _TXT_DIS__E_MENU_TEXT_DISPLAY8                                       10

//����E_menu�ж����ؼ�Icon1ʹ�õ�ͼƬ
#define  _IMG_E_MENU_ICON1                                                     4

#define  _ANIMATION_E_MENU_ICON1                                              19

//����E_menu�ж����ؼ�Icon2ʹ�õ�ͼƬ
#define  _IMG_E_MENU_ICON2                                                     4

#define  _ANIMATION_E_MENU_ICON2                                              20

//����E_menu�ж����ؼ�Icon3ʹ�õ�ͼƬ
#define  _IMG_E_MENU_ICON3                                                     4

#define  _ANIMATION_E_MENU_ICON3                                              14

//����E_menu�ж����ؼ�Icon4ʹ�õ�ͼƬ
#define  _IMG_E_MENU_ICON4                                                    26

#define  _ANIMATION_E_MENU_ICON4                                              15

//����E_menu�ж����ؼ�Icon5ʹ�õ�ͼƬ
#define  _IMG_E_MENU_ICON5                                                     4

#define  _ANIMATION_E_MENU_ICON5                                              16

//����E_menu�ж����ؼ�Icon6ʹ�õ�ͼƬ
#define  _IMG_E_MENU_ICON6                                                     4

#define  _ANIMATION_E_MENU_ICON6                                              17

#define  _BTN_E_MENU_BUTTON3                                                  22

#define  _BTN_E_MENU_BUTTON4                                                  23

#define  _BTN_E_MENU_BUTTON5                                                  24

#define  _BTN_E_MENU_BUTTON6                                                  25

#define  _BTN_E_MENU_BUTTON7                                                  26

#define  _BTN_E_MENU_BUTTON8                                                  27

//����E_shutoff_recovery��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_E_SHUTOFF_RECOVERY_IMAGE1                                       27

#define  _TXT_DIS__E_SHUTOFF_RECOVERY_TEXT_DISPLAY1                            2

//����E_time��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_E_TIME_IMAGE1                                                   28

#define  _TXT_DIS__E_TIME_TEXT_DISPLAY1                                        2

#define  _TXT_DIS__E_TIME_TEXT_DISPLAY2                                        3

#define  _TXT_DIS__E_TIME_TEXT_DISPLAY3                                        4

#define  _TXT_DIS__E_TIME_TEXT_DISPLAY4                                        5

#define  _TXT_DIS__E_TIME_TEXT_DISPLAY5                                        6

#define  _TXT_DIS__E_TIME_TEXT_DISPLAY6                                        7

#define  _BTN_E_TIME_BUTTON1                                                   8

//����E_wrong_password��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_E_WRONG_PASSWORD_IMAGE1                                         29

#define  _BTN_E_WRONG_PASSWORD_BUTTON1                                         2

//����E_wrong_setting��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_E_WRONG_SETTING_IMAGE1                                          30

//����E_wrong_setting�ж����ؼ�Icon1ʹ�õ�ͼƬ
#define  _IMG_E_WRONG_SETTING_ICON1                                            9

#define  _ANIMATION_E_WRONG_SETTING_ICON1                                      2

//����E_wrong_setting�ж����ؼ�Icon2ʹ�õ�ͼƬ
#define  _IMG_E_WRONG_SETTING_ICON2                                            9

#define  _ANIMATION_E_WRONG_SETTING_ICON2                                      3

//����E_wrong_setting�ж����ؼ�Icon3ʹ�õ�ͼƬ
#define  _IMG_E_WRONG_SETTING_ICON3                                            9

#define  _ANIMATION_E_WRONG_SETTING_ICON3                                      4

//����E_wrong_setting�ж����ؼ�Icon4ʹ�õ�ͼƬ
#define  _IMG_E_WRONG_SETTING_ICON4                                            9

#define  _ANIMATION_E_WRONG_SETTING_ICON4                                      5

//����E_wrong_setting�ж����ؼ�Icon5ʹ�õ�ͼƬ
#define  _IMG_E_WRONG_SETTING_ICON5                                            9

#define  _ANIMATION_E_WRONG_SETTING_ICON5                                      6

//����E_wrong_setting�ж����ؼ�Icon6ʹ�õ�ͼƬ
#define  _IMG_E_WRONG_SETTING_ICON6                                            9

#define  _ANIMATION_E_WRONG_SETTING_ICON6                                      8

//����E_wrong_setting�ж����ؼ�Icon7ʹ�õ�ͼƬ
#define  _IMG_E_WRONG_SETTING_ICON7                                            9

#define  _ANIMATION_E_WRONG_SETTING_ICON7                                      9

#define  _BTN_E_WRONG_SETTING_BUTTON1                                         10

//����E_wrong_setting2��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_E_WRONG_SETTING2_IMAGE1                                         31

//����E_wrong_setting2�ж����ؼ�Icon7ʹ�õ�ͼƬ
#define  _IMG_E_WRONG_SETTING2_ICON7                                           9

#define  _ANIMATION_E_WRONG_SETTING2_ICON7                                     2

//����E_wrong_setting2�ж����ؼ�Icon1ʹ�õ�ͼƬ
#define  _IMG_E_WRONG_SETTING2_ICON1                                           9

#define  _ANIMATION_E_WRONG_SETTING2_ICON1                                     4

//����E_wrong_setting2�ж����ؼ�Icon2ʹ�õ�ͼƬ
#define  _IMG_E_WRONG_SETTING2_ICON2                                           9

#define  _ANIMATION_E_WRONG_SETTING2_ICON2                                     5

#define  _BTN_E_WRONG_SETTING2_BUTTON1                                         6

//����E_main��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_E_MAIN_IMAGE1                                                   32

//����E_main�ж����ؼ�Icon1ʹ�õ�ͼƬ
#define  _IMG_E_MAIN_ICON1                                                    12

#define  _ANIMATION_E_MAIN_ICON1                                               2

//����E_main�ж����ؼ�Icon3ʹ�õ�ͼƬ
#define  _IMG_E_MAIN_ICON3                                                    13

#define  _ANIMATION_E_MAIN_ICON3                                               4

//����E_main�ж����ؼ�Icon5ʹ�õ�ͼƬ
#define  _IMG_E_MAIN_ICON5                                                    14

#define  _ANIMATION_E_MAIN_ICON5                                               6

//����E_main�ж����ؼ�Icon6ʹ�õ�ͼƬ
#define  _IMG_E_MAIN_ICON6                                                    15

#define  _ANIMATION_E_MAIN_ICON6                                               5

//����E_main�ж����ؼ�Icon8ʹ�õ�ͼƬ
#define  _IMG_E_MAIN_ICON8                                                    16

#define  _ANIMATION_E_MAIN_ICON8                                              12

//����E_main�ж����ؼ�Icon9ʹ�õ�ͼƬ
#define  _IMG_E_MAIN_ICON9                                                    17

#define  _ANIMATION_E_MAIN_ICON9                                              14

#define  _TXT_DIS__E_MAIN_TEXT_DISPLAY1                                       21

#define  _TXT_DIS__E_MAIN_TEXT_DISPLAY2                                       23

#define  _TXT_DIS__E_MAIN_TEXT_DISPLAY3                                       25

#define  _TXT_DIS__E_MAIN_TEXT_DISPLAY4                                       26

#define  _TXT_DIS__E_MAIN_TEXT_DISPLAY5                                       29

#define  _TXT_DIS__E_MAIN_TEXT_DISPLAY6                                       28

#define  _TXT_DIS__E_MAIN_TEXT_DISPLAY7                                       27

//����E_main�ж����ؼ�Icon4ʹ�õ�ͼƬ
#define  _IMG_E_MAIN_ICON4                                                    18

#define  _ANIMATION_E_MAIN_ICON4                                              33

#define  _TXT_DIS__E_MAIN_TEXT_DISPLAY8                                       34

#define  _BTN_E_MAIN_BUTTON1                                                  16

#define  _BTN_E_MAIN_BUTTON4                                                  20

#define  _TXT_DIS__E_MAIN_TEXT_DISPLAY9                                       22

#define  _TXT_DIS__E_MAIN_TEXT_DISPLAY10                                      24

#define  _TXT_DIS__E_MAIN_TEXT_DISPLAY11                                      30

//����E_main�ж����ؼ�Icon2ʹ�õ�ͼƬ
#define  _IMG_E_MAIN_ICON2                                                    19

#define  _ANIMATION_E_MAIN_ICON2                                               3

#define  _BTN_E_MAIN_BUTTON2                                                  19

#define  _RTC_E_MAIN_RTC1                                                      7

//����E_main�ж����ؼ�Icon7ʹ�õ�ͼƬ
#define  _IMG_E_MAIN_ICON7                                                    20

#define  _ANIMATION_E_MAIN_ICON7                                             340

//����E_main�ж����ؼ�Icon10ʹ�õ�ͼƬ
#define  _IMG_E_MAIN_ICON10                                                   20

#define  _ANIMATION_E_MAIN_ICON10                                            330

//����E_adjustmenu��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_E_ADJUSTMENU_IMAGE1                                             33

#define  _TXT_DIS__E_ADJUSTMENU_TEXT_DISPLAY1                                  2

#define  _TXT_DIS__E_ADJUSTMENU_TEXT_DISPLAY2                                  3

#define  _TXT_DIS__E_ADJUSTMENU_TEXT_DISPLAY4                                  5

#define  _TXT_DIS__E_ADJUSTMENU_TEXT_DISPLAY5                                  6

#define  _TXT_DIS__E_ADJUSTMENU_TEXT_DISPLAY6                                  7

#define  _TXT_DIS__E_ADJUSTMENU_TEXT_DISPLAY7                                  8

#define  _BTN_E_ADJUSTMENU_BUTTON2                                             9

#define  _BTN_E_ADJUSTMENU_BUTTON4                                            11

//����E_ErrorTime��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_E_ERRORTIME_IMAGE1                                              34

#define  _BTN_E_ERRORTIME_BUTTON1                                              2

#define  _TXT_DIS__E_ERRORTIME_TEXT_DISPLAY1                                   3

