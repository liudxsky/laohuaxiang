//��������keyboard����������ID
#define  _SCREEN_KEYBOARD                                                      0

//��������S_gate_editing����������ID
#define  _SCREEN_S_GATE_EDITING                                                1

//��������S_password����������ID
#define  _SCREEN_S_PASSWORD                                                    2

//��������S_password2����������ID
#define  _SCREEN_S_PASSWORD2                                                   3

//��������S_PID����������ID
#define  _SCREEN_S_PID                                                         4

//��������S_Menu����������ID
#define  _SCREEN_S_MENU                                                        5

//��������S_recoverpassword����������ID
#define  _SCREEN_S_RECOVERPASSWORD                                             6

//��������S_door_open����������ID
#define  _SCREEN_S_DOOR_OPEN                                                   7

//��������S_time����������ID
#define  _SCREEN_S_TIME                                                        8

//��������S_wrong_password����������ID
#define  _SCREEN_S_WRONG_PASSWORD                                              9

//��������S_invalid_setting����������ID
#define  _SCREEN_S_INVALID_SETTING                                            10

//��������S_invalid_setting2����������ID
#define  _SCREEN_S_INVALID_SETTING2                                           11

//��������S_main����������ID
#define  _SCREEN_S_MAIN                                                       12

//��������S_Adjust����������ID
#define  _SCREEN_S_ADJUST                                                     13

//��������S_ErrorTime����������ID
#define  _SCREEN_S_ERRORTIME                                                  14

//��������E_gate_editing����������ID
#define  _SCREEN_E_GATE_EDITING                                               15

//��������E_password����������ID
#define  _SCREEN_E_PASSWORD                                                   16

//��������E_password2����������ID
#define  _SCREEN_E_PASSWORD2                                                  17

//��������E_PID����������ID
#define  _SCREEN_E_PID                                                        18

//��������E_Menu����������ID
#define  _SCREEN_E_MENU                                                       19

//��������E_recoverpassword����������ID
#define  _SCREEN_E_RECOVERPASSWORD                                            20

//��������E_door_open����������ID
#define  _SCREEN_E_DOOR_OPEN                                                  21

//��������E_time����������ID
#define  _SCREEN_E_TIME                                                       22

//��������E_wrong_password����������ID
#define  _SCREEN_E_WRONG_PASSWORD                                             23

//��������E_invalid_setting����������ID
#define  _SCREEN_E_INVALID_SETTING                                            24

//��������E_invalid_setting2����������ID
#define  _SCREEN_E_INVALID_SETTING2                                           25

//��������E_Main����������ID
#define  _SCREEN_E_MAIN                                                       26

//��������E_adjust����������ID
#define  _SCREEN_E_ADJUST                                                     27

//��������E_ErrorTime����������ID
#define  _SCREEN_E_ERRORTIME                                                  28

//����keyboard��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_KEYBOARD_IMAGE1                                                  0

#define  _TXT_DIS__KEYBOARD_TEXT_DISPLAY1                                      2

#define  _BTN_KEYBOARD_BUTTON1                                                 3

#define  _BTN_KEYBOARD_BUTTON2                                                 4

#define  _BTN_KEYBOARD_BUTTON3                                                 5

#define  _BTN_KEYBOARD_BUTTON4                                                 6

#define  _BTN_KEYBOARD_BUTTON5                                                 7

#define  _BTN_KEYBOARD_BUTTON6                                                 8

#define  _BTN_KEYBOARD_BUTTON7                                                 9

#define  _BTN_KEYBOARD_BUTTON8                                                10

#define  _BTN_KEYBOARD_BUTTON9                                                11

#define  _BTN_KEYBOARD_BUTTON10                                               12

#define  _BTN_KEYBOARD_BUTTON11                                               13

#define  _BTN_KEYBOARD_BUTTON12                                               14

#define  _BTN_KEYBOARD_BUTTON13                                               15

#define  _BTN_KEYBOARD_BUTTON14                                               16

#define  _BTN_KEYBOARD_BUTTON15                                               17

//����S_gate_editing��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_S_GATE_EDITING_IMAGE1                                            1

#define  _TXT_DIS__S_GATE_EDITING_TEXT_DISPLAY1                                2

#define  _TXT_DIS__S_GATE_EDITING_TEXT_DISPLAY2                                3

#define  _TXT_DIS__S_GATE_EDITING_TEXT_DISPLAY3                                4

#define  _TXT_DIS__S_GATE_EDITING_TEXT_DISPLAY4                                5

#define  _TXT_DIS__S_GATE_EDITING_TEXT_DISPLAY5                                6

#define  _TXT_DIS__S_GATE_EDITING_TEXT_DISPLAY6                                7

#define  _TXT_DIS__S_GATE_EDITING_TEXT_DISPLAY7                                8

#define  _TXT_DIS__S_GATE_EDITING_TEXT_DISPLAY8                                9

#define  _TXT_DIS__S_GATE_EDITING_TEXT_DISPLAY9                               10

#define  _TXT_DIS__S_GATE_EDITING_TEXT_DISPLAY10                              11

#define  _TXT_DIS__S_GATE_EDITING_TEXT_DISPLAY11                              12

#define  _TXT_DIS__S_GATE_EDITING_TEXT_DISPLAY12                              13

#define  _TXT_DIS__S_GATE_EDITING_TEXT_DISPLAY13                              14

#define  _TXT_DIS__S_GATE_EDITING_TEXT_DISPLAY14                              15

#define  _TXT_DIS__S_GATE_EDITING_TEXT_DISPLAY15                              16

#define  _TXT_DIS__S_GATE_EDITING_TEXT_DISPLAY16                              17

#define  _TXT_DIS__S_GATE_EDITING_TEXT_DISPLAY17                              18

#define  _TXT_DIS__S_GATE_EDITING_TEXT_DISPLAY18                              19

#define  _TXT_DIS__S_GATE_EDITING_TEXT_DISPLAY19                              20

#define  _TXT_DIS__S_GATE_EDITING_TEXT_DISPLAY20                              21

#define  _TXT_DIS__S_GATE_EDITING_TEXT_DISPLAY21                              22

#define  _BTN_S_GATE_EDITING_BUTTON1                                          23

//����S_password��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_S_PASSWORD_IMAGE1                                                2

#define  _TXT_DIS__S_PASSWORD_TEXT_DISPLAY1                                    2

//����S_password2��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_S_PASSWORD2_IMAGE1                                               2

#define  _TXT_DIS__S_PASSWORD2_TEXT_DISPLAY1                                   2

//����S_PID��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_S_PID_IMAGE1                                                     3

#define  _BTN_S_PID_BUTTON1                                                    2

#define  _BTN_S_PID_BUTTON2                                                    3

#define  _TXT_DIS__S_PID_TEXT_DISPLAY1                                         4

#define  _TXT_DIS__S_PID_TEXT_DISPLAY2                                         5

#define  _TXT_DIS__S_PID_TEXT_DISPLAY3                                         6

//����S_Menu��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_S_MENU_IMAGE1                                                    4

#define  _BTN_S_MENU_BUTTON1                                                   2

#define  _TXT_DIS__S_MENU_TEXT_DISPLAY1                                        3

#define  _TXT_DIS__S_MENU_TEXT_DISPLAY2                                        4

#define  _TXT_DIS__S_MENU_TEXT_DISPLAY3                                        5

#define  _TXT_DIS__S_MENU_TEXT_DISPLAY4                                        6

#define  _TXT_DIS__S_MENU_TEXT_DISPLAY5                                        7

#define  _TXT_DIS__S_MENU_TEXT_DISPLAY6                                        8

#define  _TXT_DIS__S_MENU_TEXT_DISPLAY7                                        9

#define  _TXT_DIS__S_MENU_TEXT_DISPLAY8                                       10

#define  _TXT_DIS__S_MENU_TEXT_DISPLAY9                                       11

#define  _TXT_DIS__S_MENU_TEXT_DISPLAY10                                      12

#define  _TXT_DIS__S_MENU_TEXT_DISPLAY11                                      13

//����S_Menu�ж����ؼ�Icon1ʹ�õ�ͼƬ
#define  _IMG_S_MENU_ICON1                                                     5

#define  _ANIMATION_S_MENU_ICON1                                              14

//����S_Menu�ж����ؼ�Icon2ʹ�õ�ͼƬ
#define  _IMG_S_MENU_ICON2                                                     6

#define  _ANIMATION_S_MENU_ICON2                                              15

//����S_Menu�ж����ؼ�Icon3ʹ�õ�ͼƬ
#define  _IMG_S_MENU_ICON3                                                     7

#define  _ANIMATION_S_MENU_ICON3                                              16

//����S_Menu�ж����ؼ�Icon4ʹ�õ�ͼƬ
#define  _IMG_S_MENU_ICON4                                                     8

#define  _ANIMATION_S_MENU_ICON4                                              17

#define  _TXT_DIS__S_MENU_TEXT_DISPLAY12                                      18

//����S_Menu�ж����ؼ�Icon5ʹ�õ�ͼƬ
#define  _IMG_S_MENU_ICON5                                                     9

#define  _ANIMATION_S_MENU_ICON5                                              19

//����S_Menu�ж����ؼ�Icon6ʹ�õ�ͼƬ
#define  _IMG_S_MENU_ICON6                                                    10

#define  _ANIMATION_S_MENU_ICON6                                              20

#define  _BTN_S_MENU_BUTTON2                                                  21

#define  _BTN_S_MENU_BUTTON3                                                  22

#define  _BTN_S_MENU_BUTTON4                                                  23

#define  _BTN_S_MENU_BUTTON5                                                  24

#define  _BTN_S_MENU_BUTTON6                                                  25

#define  _BTN_S_MENU_BUTTON7                                                  26

#define  _BTN_S_MENU_BUTTON8                                                  27

//����S_recoverpassword��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_S_RECOVERPASSWORD_IMAGE1                                        11

#define  _TXT_DIS__S_RECOVERPASSWORD_TEXT_DISPLAY1                             2

//����S_door_open��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_S_DOOR_OPEN_IMAGE1                                              12

#define  _RECORD_S_DOOR_OPEN_RECORD1                                           2

#define  _BTN_S_DOOR_OPEN_BUTTON1                                              3

//����S_time��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_S_TIME_IMAGE1                                                   13

#define  _TXT_DIS__S_TIME_TEXT_DISPLAY1                                        2

#define  _TXT_DIS__S_TIME_TEXT_DISPLAY2                                        3

#define  _TXT_DIS__S_TIME_TEXT_DISPLAY3                                        4

#define  _TXT_DIS__S_TIME_TEXT_DISPLAY4                                        5

#define  _TXT_DIS__S_TIME_TEXT_DISPLAY5                                        6

#define  _TXT_DIS__S_TIME_TEXT_DISPLAY6                                        7

#define  _BTN_S_TIME_BUTTON2                                                   8

//����S_wrong_password��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_S_WRONG_PASSWORD_IMAGE1                                         14

#define  _BTN_S_WRONG_PASSWORD_BUTTON2                                         2

//����S_invalid_setting��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_S_INVALID_SETTING_IMAGE1                                        15

#define  _BTN_S_INVALID_SETTING_BUTTON2                                       10

//����S_invalid_setting�ж����ؼ�Icon1ʹ�õ�ͼƬ
#define  _IMG_S_INVALID_SETTING_ICON1                                         16

#define  _ANIMATION_S_INVALID_SETTING_ICON1                                    2

//����S_invalid_setting�ж����ؼ�Icon2ʹ�õ�ͼƬ
#define  _IMG_S_INVALID_SETTING_ICON2                                         16

#define  _ANIMATION_S_INVALID_SETTING_ICON2                                    3

//����S_invalid_setting�ж����ؼ�Icon3ʹ�õ�ͼƬ
#define  _IMG_S_INVALID_SETTING_ICON3                                         16

#define  _ANIMATION_S_INVALID_SETTING_ICON3                                    4

//����S_invalid_setting�ж����ؼ�Icon4ʹ�õ�ͼƬ
#define  _IMG_S_INVALID_SETTING_ICON4                                         16

#define  _ANIMATION_S_INVALID_SETTING_ICON4                                    5

//����S_invalid_setting�ж����ؼ�Icon5ʹ�õ�ͼƬ
#define  _IMG_S_INVALID_SETTING_ICON5                                         16

#define  _ANIMATION_S_INVALID_SETTING_ICON5                                    6

//����S_invalid_setting�ж����ؼ�Icon6ʹ�õ�ͼƬ
#define  _IMG_S_INVALID_SETTING_ICON6                                         16

#define  _ANIMATION_S_INVALID_SETTING_ICON6                                    7

//����S_invalid_setting�ж����ؼ�Icon7ʹ�õ�ͼƬ
#define  _IMG_S_INVALID_SETTING_ICON7                                         16

#define  _ANIMATION_S_INVALID_SETTING_ICON7                                    8

//����S_invalid_setting�ж����ؼ�Icon8ʹ�õ�ͼƬ
#define  _IMG_S_INVALID_SETTING_ICON8                                         16

#define  _ANIMATION_S_INVALID_SETTING_ICON8                                    9

//����S_invalid_setting2�ı���ͼƬ
#define  _IMG_S_INVALID_SETTING2                                              17

//����S_invalid_setting2��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_S_INVALID_SETTING2_IMAGE1                                       17

//����S_invalid_setting2�ж����ؼ�Icon6ʹ�õ�ͼƬ
#define  _IMG_S_INVALID_SETTING2_ICON6                                        16

#define  _ANIMATION_S_INVALID_SETTING2_ICON6                                   5

//����S_invalid_setting2�ж����ؼ�Icon1ʹ�õ�ͼƬ
#define  _IMG_S_INVALID_SETTING2_ICON1                                        16

#define  _ANIMATION_S_INVALID_SETTING2_ICON1                                   4

//����S_invalid_setting2�ж����ؼ�Icon2ʹ�õ�ͼƬ
#define  _IMG_S_INVALID_SETTING2_ICON2                                        16

#define  _ANIMATION_S_INVALID_SETTING2_ICON2                                   3

//����S_invalid_setting2�ж����ؼ�Icon3ʹ�õ�ͼƬ
#define  _IMG_S_INVALID_SETTING2_ICON3                                        16

#define  _ANIMATION_S_INVALID_SETTING2_ICON3                                   2

#define  _BTN_S_INVALID_SETTING2_BUTTON1                                       6

//����S_main��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_S_MAIN_IMAGE1                                                   18

#define  _TXT_DIS__S_MAIN_TEXT_DISPLAY10                                      32

//����S_main�ж����ؼ�Icon1ʹ�õ�ͼƬ
#define  _IMG_S_MAIN_ICON1                                                    19

#define  _ANIMATION_S_MAIN_ICON1                                               2

//����S_main�ж����ؼ�Icon2ʹ�õ�ͼƬ
#define  _IMG_S_MAIN_ICON2                                                    20

#define  _ANIMATION_S_MAIN_ICON2                                               3

//����S_main�ж����ؼ�Icon3ʹ�õ�ͼƬ
#define  _IMG_S_MAIN_ICON3                                                    21

#define  _ANIMATION_S_MAIN_ICON3                                               4

//����S_main�ж����ؼ�Icon4ʹ�õ�ͼƬ
#define  _IMG_S_MAIN_ICON4                                                    22

#define  _ANIMATION_S_MAIN_ICON4                                               5

//����S_main�ж����ؼ�Icon5ʹ�õ�ͼƬ
#define  _IMG_S_MAIN_ICON5                                                    23

#define  _ANIMATION_S_MAIN_ICON5                                               6

//����S_main�ж����ؼ�Icon6ʹ�õ�ͼƬ
#define  _IMG_S_MAIN_ICON6                                                    24

#define  _ANIMATION_S_MAIN_ICON6                                               7

//����S_main�ж����ؼ�Icon7ʹ�õ�ͼƬ
#define  _IMG_S_MAIN_ICON7                                                    25

#define  _ANIMATION_S_MAIN_ICON7                                               8

//����S_main�ж����ؼ�Icon8ʹ�õ�ͼƬ
#define  _IMG_S_MAIN_ICON8                                                    26

#define  _ANIMATION_S_MAIN_ICON8                                               9

//����S_main�ж����ؼ�Icon9ʹ�õ�ͼƬ
#define  _IMG_S_MAIN_ICON9                                                    27

#define  _ANIMATION_S_MAIN_ICON9                                              10

//����S_main�ж����ؼ�Icon10ʹ�õ�ͼƬ
#define  _IMG_S_MAIN_ICON10                                                   28

#define  _ANIMATION_S_MAIN_ICON10                                             33

//����S_main�ж����ؼ�Icon11ʹ�õ�ͼƬ
#define  _IMG_S_MAIN_ICON11                                                   29

#define  _ANIMATION_S_MAIN_ICON11                                             11

//����S_main�ж����ؼ�Icon12ʹ�õ�ͼƬ
#define  _IMG_S_MAIN_ICON12                                                   30

#define  _ANIMATION_S_MAIN_ICON12                                             12

//����S_main�ж����ؼ�Icon13ʹ�õ�ͼƬ
#define  _IMG_S_MAIN_ICON13                                                   31

#define  _ANIMATION_S_MAIN_ICON13                                             13

//����S_main�ж����ؼ�Icon14ʹ�õ�ͼƬ
#define  _IMG_S_MAIN_ICON14                                                   32

#define  _ANIMATION_S_MAIN_ICON14                                             14

//����S_main�ж����ؼ�Icon15ʹ�õ�ͼƬ
#define  _IMG_S_MAIN_ICON15                                                   32

#define  _ANIMATION_S_MAIN_ICON15                                             15

#define  _RTC_S_MAIN_RTC1                                                     35

#define  _BTN_S_MAIN_BUTTON1                                                  16

#define  _BTN_S_MAIN_BUTTON2                                                  17

#define  _BTN_S_MAIN_BUTTON3                                                  18

#define  _BTN_S_MAIN_BUTTON4                                                  19

#define  _BTN_S_MAIN_BUTTON5                                                  20

#define  _TXT_DIS__S_MAIN_TEXT_DISPLAY1                                       21

#define  _TXT_DIS__S_MAIN_TEXT_DISPLAY2                                       22

#define  _TXT_DIS__S_MAIN_TEXT_DISPLAY3                                       23

#define  _TXT_DIS__S_MAIN_TEXT_DISPLAY4                                       24

#define  _TXT_DIS__S_MAIN_TEXT_DISPLAY5                                       25

#define  _TXT_DIS__S_MAIN_TEXT_DISPLAY6                                       26

#define  _TXT_DIS__S_MAIN_TEXT_DISPLAY7                                       27

#define  _TXT_DIS__S_MAIN_TEXT_DISPLAY8                                       28

#define  _TXT_DIS__S_MAIN_TEXT_DISPLAY9                                       29

#define  _TXT_DIS__S_MAIN_TEXT_DISPLAY11                                      30

#define  _TXT_DIS__S_MAIN_TEXT_DISPLAY12                                      31

#define  _TXT_DIS__S_MAIN_TEXT_DISPLAY13                                      34

//����S_Adjust��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_S_ADJUST_IMAGE1                                                 33

#define  _TXT_DIS__S_ADJUST_TEXT_DISPLAY1                                      2

#define  _TXT_DIS__S_ADJUST_TEXT_DISPLAY2                                      3

#define  _TXT_DIS__S_ADJUST_TEXT_DISPLAY3                                      4

#define  _TXT_DIS__S_ADJUST_TEXT_DISPLAY4                                      5

#define  _TXT_DIS__S_ADJUST_TEXT_DISPLAY5                                      6

#define  _TXT_DIS__S_ADJUST_TEXT_DISPLAY6                                      7

#define  _TXT_DIS__S_ADJUST_TEXT_DISPLAY7                                      8

#define  _BTN_S_ADJUST_BUTTON1                                                 9

#define  _BTN_S_ADJUST_BUTTON2                                                10

#define  _BTN_S_ADJUST_BUTTON3                                                11

#define  _TXT_DIS__S_ADJUST_TEXT_DISPLAY8                                     12

//����S_ErrorTime��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_S_ERRORTIME_IMAGE1                                              34

#define  _BTN_S_ERRORTIME_BUTTON1                                              2

#define  _TXT_DIS__S_ERRORTIME_TEXT_DISPLAY1                                   3

//����E_gate_editing��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_E_GATE_EDITING_IMAGE1                                           35

#define  _TXT_DIS__E_GATE_EDITING_TEXT_DISPLAY1                                2

#define  _TXT_DIS__E_GATE_EDITING_TEXT_DISPLAY2                                3

#define  _TXT_DIS__E_GATE_EDITING_TEXT_DISPLAY3                                4

#define  _TXT_DIS__E_GATE_EDITING_TEXT_DISPLAY4                                5

#define  _TXT_DIS__E_GATE_EDITING_TEXT_DISPLAY5                                6

#define  _TXT_DIS__E_GATE_EDITING_TEXT_DISPLAY6                                7

#define  _TXT_DIS__E_GATE_EDITING_TEXT_DISPLAY7                                8

#define  _TXT_DIS__E_GATE_EDITING_TEXT_DISPLAY8                                9

#define  _TXT_DIS__E_GATE_EDITING_TEXT_DISPLAY9                               10

#define  _TXT_DIS__E_GATE_EDITING_TEXT_DISPLAY10                              11

#define  _TXT_DIS__E_GATE_EDITING_TEXT_DISPLAY11                              12

#define  _TXT_DIS__E_GATE_EDITING_TEXT_DISPLAY12                              13

#define  _TXT_DIS__E_GATE_EDITING_TEXT_DISPLAY13                              14

#define  _TXT_DIS__E_GATE_EDITING_TEXT_DISPLAY14                              15

#define  _TXT_DIS__E_GATE_EDITING_TEXT_DISPLAY15                              16

#define  _TXT_DIS__E_GATE_EDITING_TEXT_DISPLAY16                              17

#define  _TXT_DIS__E_GATE_EDITING_TEXT_DISPLAY17                              18

#define  _TXT_DIS__E_GATE_EDITING_TEXT_DISPLAY18                              19

#define  _TXT_DIS__E_GATE_EDITING_TEXT_DISPLAY19                              20

#define  _TXT_DIS__E_GATE_EDITING_TEXT_DISPLAY20                              21

#define  _TXT_DIS__E_GATE_EDITING_TEXT_DISPLAY21                              22

#define  _BTN_E_GATE_EDITING_BUTTON1                                          23

//����E_password��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_E_PASSWORD_IMAGE1                                               36

#define  _TXT_DIS__E_PASSWORD_TEXT_DISPLAY1                                    2

//����E_password2��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_E_PASSWORD2_IMAGE1                                              36

#define  _TXT_DIS__E_PASSWORD2_TEXT_DISPLAY1                                   2

//����E_PID��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_E_PID_IMAGE1                                                    37

#define  _BTN_E_PID_BUTTON1                                                    2

#define  _BTN_E_PID_BUTTON2                                                    3

#define  _TXT_DIS__E_PID_TEXT_DISPLAY1                                         4

#define  _TXT_DIS__E_PID_TEXT_DISPLAY2                                         5

#define  _TXT_DIS__E_PID_TEXT_DISPLAY3                                         6

//����E_Menu��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_E_MENU_IMAGE1                                                   38

#define  _BTN_E_MENU_BUTTON1                                                   2

#define  _TXT_DIS__E_MENU_TEXT_DISPLAY1                                        3

#define  _TXT_DIS__E_MENU_TEXT_DISPLAY2                                        4

#define  _TXT_DIS__E_MENU_TEXT_DISPLAY3                                        5

#define  _TXT_DIS__E_MENU_TEXT_DISPLAY4                                        6

#define  _TXT_DIS__E_MENU_TEXT_DISPLAY5                                        7

#define  _TXT_DIS__E_MENU_TEXT_DISPLAY6                                        8

#define  _TXT_DIS__E_MENU_TEXT_DISPLAY7                                        9

#define  _TXT_DIS__E_MENU_TEXT_DISPLAY8                                       10

#define  _TXT_DIS__E_MENU_TEXT_DISPLAY9                                       11

#define  _TXT_DIS__E_MENU_TEXT_DISPLAY10                                      12

#define  _TXT_DIS__E_MENU_TEXT_DISPLAY11                                      13

//����E_Menu�ж����ؼ�Icon1ʹ�õ�ͼƬ
#define  _IMG_E_MENU_ICON1                                                     5

#define  _ANIMATION_E_MENU_ICON1                                              14

//����E_Menu�ж����ؼ�Icon2ʹ�õ�ͼƬ
#define  _IMG_E_MENU_ICON2                                                     5

#define  _ANIMATION_E_MENU_ICON2                                              15

//����E_Menu�ж����ؼ�Icon3ʹ�õ�ͼƬ
#define  _IMG_E_MENU_ICON3                                                     5

#define  _ANIMATION_E_MENU_ICON3                                              16

//����E_Menu�ж����ؼ�Icon4ʹ�õ�ͼƬ
#define  _IMG_E_MENU_ICON4                                                     5

#define  _ANIMATION_E_MENU_ICON4                                              17

#define  _TXT_DIS__E_MENU_TEXT_DISPLAY12                                      18

//����E_Menu�ж����ؼ�Icon5ʹ�õ�ͼƬ
#define  _IMG_E_MENU_ICON5                                                     5

#define  _ANIMATION_E_MENU_ICON5                                              19

//����E_Menu�ж����ؼ�Icon6ʹ�õ�ͼƬ
#define  _IMG_E_MENU_ICON6                                                     5

#define  _ANIMATION_E_MENU_ICON6                                              20

#define  _BTN_E_MENU_BUTTON2                                                  21

#define  _BTN_E_MENU_BUTTON3                                                  22

#define  _BTN_E_MENU_BUTTON4                                                  23

#define  _BTN_E_MENU_BUTTON5                                                  24

#define  _BTN_E_MENU_BUTTON6                                                  25

#define  _BTN_E_MENU_BUTTON7                                                  26

#define  _BTN_E_MENU_BUTTON8                                                  27

//����E_recoverpassword��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_E_RECOVERPASSWORD_IMAGE1                                        39

#define  _TXT_DIS__E_RECOVERPASSWORD_TEXT_DISPLAY1                             2

//����E_door_open��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_E_DOOR_OPEN_IMAGE1                                              40

#define  _RECORD_E_DOOR_OPEN_RECORD1                                           2

#define  _BTN_E_DOOR_OPEN_BUTTON1                                              3

//����E_time��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_E_TIME_IMAGE1                                                   41

#define  _TXT_DIS__E_TIME_TEXT_DISPLAY1                                        2

#define  _TXT_DIS__E_TIME_TEXT_DISPLAY2                                        3

#define  _TXT_DIS__E_TIME_TEXT_DISPLAY3                                        4

#define  _TXT_DIS__E_TIME_TEXT_DISPLAY4                                        5

#define  _TXT_DIS__E_TIME_TEXT_DISPLAY5                                        6

#define  _TXT_DIS__E_TIME_TEXT_DISPLAY6                                        7

#define  _BTN_E_TIME_BUTTON1                                                   8

//����E_wrong_password��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_E_WRONG_PASSWORD_IMAGE1                                         42

#define  _BTN_E_WRONG_PASSWORD_BUTTON1                                         2

//����E_invalid_setting��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_E_INVALID_SETTING_IMAGE1                                        43

//����E_invalid_setting�ж����ؼ�Icon1ʹ�õ�ͼƬ
#define  _IMG_E_INVALID_SETTING_ICON1                                         16

#define  _ANIMATION_E_INVALID_SETTING_ICON1                                    2

//����E_invalid_setting�ж����ؼ�Icon2ʹ�õ�ͼƬ
#define  _IMG_E_INVALID_SETTING_ICON2                                         16

#define  _ANIMATION_E_INVALID_SETTING_ICON2                                    3

//����E_invalid_setting�ж����ؼ�Icon3ʹ�õ�ͼƬ
#define  _IMG_E_INVALID_SETTING_ICON3                                         16

#define  _ANIMATION_E_INVALID_SETTING_ICON3                                    4

//����E_invalid_setting�ж����ؼ�Icon4ʹ�õ�ͼƬ
#define  _IMG_E_INVALID_SETTING_ICON4                                         16

#define  _ANIMATION_E_INVALID_SETTING_ICON4                                    5

//����E_invalid_setting�ж����ؼ�Icon5ʹ�õ�ͼƬ
#define  _IMG_E_INVALID_SETTING_ICON5                                         16

#define  _ANIMATION_E_INVALID_SETTING_ICON5                                    6

//����E_invalid_setting�ж����ؼ�Icon6ʹ�õ�ͼƬ
#define  _IMG_E_INVALID_SETTING_ICON6                                         16

#define  _ANIMATION_E_INVALID_SETTING_ICON6                                    7

//����E_invalid_setting�ж����ؼ�Icon7ʹ�õ�ͼƬ
#define  _IMG_E_INVALID_SETTING_ICON7                                         16

#define  _ANIMATION_E_INVALID_SETTING_ICON7                                    8

//����E_invalid_setting�ж����ؼ�Icon8ʹ�õ�ͼƬ
#define  _IMG_E_INVALID_SETTING_ICON8                                         16

#define  _ANIMATION_E_INVALID_SETTING_ICON8                                    9

#define  _BTN_E_INVALID_SETTING_BUTTON1                                       10

//����E_invalid_setting2��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_E_INVALID_SETTING2_IMAGE1                                       44

//����E_invalid_setting2�ж����ؼ�Icon1ʹ�õ�ͼƬ
#define  _IMG_E_INVALID_SETTING2_ICON1                                        16

#define  _ANIMATION_E_INVALID_SETTING2_ICON1                                   2

//����E_invalid_setting2�ж����ؼ�Icon2ʹ�õ�ͼƬ
#define  _IMG_E_INVALID_SETTING2_ICON2                                        16

#define  _ANIMATION_E_INVALID_SETTING2_ICON2                                   3

//����E_invalid_setting2�ж����ؼ�Icon3ʹ�õ�ͼƬ
#define  _IMG_E_INVALID_SETTING2_ICON3                                        16

#define  _ANIMATION_E_INVALID_SETTING2_ICON3                                   4

//����E_invalid_setting2�ж����ؼ�Icon4ʹ�õ�ͼƬ
#define  _IMG_E_INVALID_SETTING2_ICON4                                        16

#define  _ANIMATION_E_INVALID_SETTING2_ICON4                                   5

#define  _BTN_E_INVALID_SETTING2_BUTTON1                                       6

//����E_Main��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_E_MAIN_IMAGE1                                                   45

//����E_Main�ж����ؼ�Icon1ʹ�õ�ͼƬ
#define  _IMG_E_MAIN_ICON1                                                    19

#define  _ANIMATION_E_MAIN_ICON1                                               2

//����E_Main�ж����ؼ�Icon2ʹ�õ�ͼƬ
#define  _IMG_E_MAIN_ICON2                                                    20

#define  _ANIMATION_E_MAIN_ICON2                                               3

//����E_Main�ж����ؼ�Icon3ʹ�õ�ͼƬ
#define  _IMG_E_MAIN_ICON3                                                    21

#define  _ANIMATION_E_MAIN_ICON3                                               4

//����E_Main�ж����ؼ�Icon4ʹ�õ�ͼƬ
#define  _IMG_E_MAIN_ICON4                                                    22

#define  _ANIMATION_E_MAIN_ICON4                                               5

//����E_Main�ж����ؼ�Icon5ʹ�õ�ͼƬ
#define  _IMG_E_MAIN_ICON5                                                    23

#define  _ANIMATION_E_MAIN_ICON5                                               6

//����E_Main�ж����ؼ�Icon6ʹ�õ�ͼƬ
#define  _IMG_E_MAIN_ICON6                                                    24

#define  _ANIMATION_E_MAIN_ICON6                                               7

//����E_Main�ж����ؼ�Icon7ʹ�õ�ͼƬ
#define  _IMG_E_MAIN_ICON7                                                    25

#define  _ANIMATION_E_MAIN_ICON7                                               8

//����E_Main�ж����ؼ�Icon8ʹ�õ�ͼƬ
#define  _IMG_E_MAIN_ICON8                                                    46

#define  _ANIMATION_E_MAIN_ICON8                                               9

//����E_Main�ж����ؼ�Icon9ʹ�õ�ͼƬ
#define  _IMG_E_MAIN_ICON9                                                    27

#define  _ANIMATION_E_MAIN_ICON9                                              10

//����E_Main�ж����ؼ�Icon10ʹ�õ�ͼƬ
#define  _IMG_E_MAIN_ICON10                                                   47

#define  _ANIMATION_E_MAIN_ICON10                                             11

//����E_Main�ж����ؼ�Icon11ʹ�õ�ͼƬ
#define  _IMG_E_MAIN_ICON11                                                   30

#define  _ANIMATION_E_MAIN_ICON11                                             12

//����E_Main�ж����ؼ�Icon12ʹ�õ�ͼƬ
#define  _IMG_E_MAIN_ICON12                                                   31

#define  _ANIMATION_E_MAIN_ICON12                                             13

//����E_Main�ж����ؼ�Icon13ʹ�õ�ͼƬ
#define  _IMG_E_MAIN_ICON13                                                   32

#define  _ANIMATION_E_MAIN_ICON13                                             14

//����E_Main�ж����ؼ�Icon14ʹ�õ�ͼƬ
#define  _IMG_E_MAIN_ICON14                                                   48

#define  _ANIMATION_E_MAIN_ICON14                                             15

#define  _BTN_E_MAIN_BUTTON1                                                  16

#define  _BTN_E_MAIN_BUTTON2                                                  17

#define  _BTN_E_MAIN_BUTTON3                                                  18

#define  _BTN_E_MAIN_BUTTON4                                                  19

#define  _BTN_E_MAIN_BUTTON5                                                  20

#define  _TXT_DIS__E_MAIN_TEXT_DISPLAY1                                       21

#define  _TXT_DIS__E_MAIN_TEXT_DISPLAY2                                       22

#define  _TXT_DIS__E_MAIN_TEXT_DISPLAY3                                       23

#define  _TXT_DIS__E_MAIN_TEXT_DISPLAY4                                       24

#define  _TXT_DIS__E_MAIN_TEXT_DISPLAY5                                       25

#define  _TXT_DIS__E_MAIN_TEXT_DISPLAY6                                       26

#define  _TXT_DIS__E_MAIN_TEXT_DISPLAY7                                       27

#define  _TXT_DIS__E_MAIN_TEXT_DISPLAY8                                       28

#define  _TXT_DIS__E_MAIN_TEXT_DISPLAY9                                       29

#define  _TXT_DIS__E_MAIN_TEXT_DISPLAY10                                      30

#define  _TXT_DIS__E_MAIN_TEXT_DISPLAY11                                      31

#define  _TXT_DIS__E_MAIN_TEXT_DISPLAY12                                      32

//����E_Main�ж����ؼ�Icon15ʹ�õ�ͼƬ
#define  _IMG_E_MAIN_ICON15                                                   28

#define  _ANIMATION_E_MAIN_ICON15                                             33

#define  _TXT_DIS__E_MAIN_TEXT_DISPLAY13                                      34

#define  _RTC_E_MAIN_RTC1                                                     35

//����E_adjust��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_E_ADJUST_IMAGE1                                                 49

#define  _TXT_DIS__E_ADJUST_TEXT_DISPLAY1                                      2

#define  _TXT_DIS__E_ADJUST_TEXT_DISPLAY2                                      3

#define  _TXT_DIS__E_ADJUST_TEXT_DISPLAY3                                      4

#define  _TXT_DIS__E_ADJUST_TEXT_DISPLAY4                                      5

#define  _TXT_DIS__E_ADJUST_TEXT_DISPLAY5                                      6

#define  _TXT_DIS__E_ADJUST_TEXT_DISPLAY6                                      7

#define  _TXT_DIS__E_ADJUST_TEXT_DISPLAY7                                      8

#define  _BTN_E_ADJUST_BUTTON1                                                 9

#define  _BTN_E_ADJUST_BUTTON2                                                10

#define  _BTN_E_ADJUST_BUTTON3                                                11

#define  _TXT_DIS__E_ADJUST_TEXT_DISPLAY8                                     12

//����E_ErrorTime��ͼƬImage1ʹ�õ�ͼƬ
#define  _IMG_E_ERRORTIME_IMAGE1                                              50

#define  _BTN_E_ERRORTIME_BUTTON1                                              2

#define  _TXT_DIS__E_ERRORTIME_TEXT_DISPLAY1                                   3

